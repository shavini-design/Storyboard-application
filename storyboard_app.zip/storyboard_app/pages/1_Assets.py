import streamlit as st
import os
import json
import base64
import io
from PIL import Image, ImageDraw, ImageFont
from openai import OpenAI
from dotenv import load_dotenv

# -------------------------
# EDIT STATE (NEW)
# -------------------------
if "edit_mode" not in st.session_state:
    st.session_state["edit_mode"] = None
if "edit_target" not in st.session_state:
    st.session_state["edit_target"] = None

# -------------------------
# ENV & OPENAI
# -------------------------
load_dotenv()
API_KEY = os.getenv("OPENAI_API_KEY")
client = OpenAI(api_key=API_KEY) if API_KEY else None

st.set_page_config(page_title="Assets", page_icon="🎭", layout="wide")

# -------------------------
# PATHS
# -------------------------
DATA_DIR = "data"
ASSETS_JSON = os.path.join(DATA_DIR, "assets.json")
CHAR_DIR = os.path.join(DATA_DIR, "assets", "characters")
LOC_DIR = os.path.join(DATA_DIR, "assets", "locations")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(CHAR_DIR, exist_ok=True)
os.makedirs(LOC_DIR, exist_ok=True)

# -------------------------
# LOAD/SAVE
# -------------------------
def load_assets():
    if not os.path.exists(ASSETS_JSON):
        return {"characters": [], "locations": []}
    try:
        return json.load(open(ASSETS_JSON, "r"))
    except:
        return {"characters": [], "locations": []}

def save_assets(data):
    json.dump(data, open(ASSETS_JSON, "w"), indent=4)

assets = load_assets()

def slugify_name(name):
    base = name.strip().lower().replace(" ", "_")
    safe = "".join(ch for ch in base if ch.isalnum() or ch in ("_", "-"))
    return safe or "asset"

# -------------------------
# AI PLACEHOLDER
# -------------------------
def create_placeholder(text, out_path):
    img = Image.new("RGB", (800, 800), (40, 40, 40))
    draw = ImageDraw.Draw(img)

    try:
        font = ImageFont.truetype("arial.ttf", 32)
    except:
        font = ImageFont.load_default()

    lines = text.split("\n")

    total_height = 0
    line_heights = []
    max_width = 0

    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        line_heights.append(h)
        total_height += h + 10
        max_width = max(max_width, w)

    y = (800 - total_height) // 2

    for i, line in enumerate(lines):
        bbox = draw.textbbox((0, 0), line, font=font)
        w = bbox[2] - bbox[0]
        draw.text(((800 - w) / 2, y), line, fill=(220, 220, 220), font=font)
        y += line_heights[i] + 10

    img.save(out_path)
    return img

# -------------------------
# AI GENERATION
# -------------------------
def generate_ai_image(prompt, out_path, label):
    if client is None:
        return create_placeholder(f"NO API KEY\n{label}", out_path)
    try:
        result = client.images.generate(
            model="gpt-4o-mini-image",
            prompt=prompt,
            size="1024x1024"
        )
        b64 = result.data[0].b64_json
        img_bytes = base64.b64decode(b64)
        img = Image.open(io.BytesIO(img_bytes)).convert("RGB")
        img.save(out_path)
        return img
    except:
        return create_placeholder(f"AI ERROR\n{label}", out_path)

# -------------------------
# LAYOUT
# -------------------------
left, right = st.columns([1, 1])

# -------------------------
# LEFT SIDE
# -------------------------
with left:
    st.markdown("### STEP 1 · ASSETS")
    st.title("🎥 Characters & Locations")
    st.write("✨ Design your story world. Add original images or let the AI help bring your ideas to life.")

    st.markdown("#### To continue, you'll need:")
    st.markdown("- **At least 1 character**")
    st.markdown("- **At least 1 location**")

    # Current Characters
    st.markdown("## Current Characters")
    if assets["characters"]:
        for c in assets["characters"]:
            cols = st.columns([1, 3])

            with cols[1]:
                st.markdown(f"**{c['name']}**")
                if c.get("description"):
                    st.caption(c["description"])

                if c.get("image_path") and os.path.exists(c["image_path"]):
                    st.image(c["image_path"], width=250)

            edit_col, del_col = st.columns([1, 1])

            with edit_col:
                if st.button(f"✏️ Edit {c['name']}", key=f"edit_char_{c['name']}"):
                    st.session_state["edit_mode"] = "character"
                    st.session_state["edit_target"] = c
                    st.rerun()

            with del_col:
                if st.button(f"🗑️ Delete {c['name']}", key=f"del_char_{c['name']}"):
                    assets["characters"] = [
                        x for x in assets["characters"] if x["name"] != c["name"]
                    ]
                    save_assets(assets)
                    st.rerun()

            st.markdown("---")
    else:
        st.caption("No characters yet.")

    # Current Locations
    st.markdown("## Current Locations")
    if assets["locations"]:
        for l in assets["locations"]:
            cols = st.columns([1, 3])

            with cols[1]:
                st.markdown(f"**{l['name']}**")
                if l.get("description"):
                    st.caption(l["description"])

                if l.get("image_path") and os.path.exists(l["image_path"]):
                    st.image(l["image_path"], width=250)

            edit_col, del_col = st.columns([1, 1])

            with edit_col:
                if st.button(f"✏️ Edit {l['name']}", key=f"edit_loc_{l['name']}"):
                    st.session_state["edit_mode"] = "location"
                    st.session_state["edit_target"] = l
                    st.rerun()

            with del_col:
                if st.button(f"🗑️ Delete {l['name']}", key=f"del_loc_{l['name']}"):
                    assets["locations"] = [
                        x for x in assets["locations"] if x["name"] != l["name"]
                    ]
                    save_assets(assets)
                    st.rerun()

            st.markdown("---")
    else:
        st.caption("No locations yet.")

    if st.button("🏠 Back to Home"):
        st.switch_page("_Home.py")

# -------------------------
# RIGHT SIDE
# -------------------------
with right:
    tabs = st.tabs(["Characters", "Locations"])

    # Characters tab
    with tabs[0]:
        st.subheader("Characters")

        if st.session_state["edit_mode"] == "character":
            pre_name = st.session_state["edit_target"]["name"]
            pre_desc = st.session_state["edit_target"].get("description", "")
        else:
            pre_name = ""
            pre_desc = ""

        cname = st.text_input("Character Name", value=pre_name)
        cdesc = st.text_area("Character Description", value=pre_desc, height=80)
        upload_file = st.file_uploader("Upload Character Image (PNG/JPG)", type=["png","jpg","jpeg"])

        if st.button("💾 Save Character (with optional upload)"):
            if not cname.strip():
                st.error("Character name is required.")
            else:
                slug = slugify_name(cname)
                image_path = None

                if upload_file:
                    img = Image.open(upload_file).convert("RGB")
                    image_path = os.path.join(CHAR_DIR, f"{slug}.png")
                    img.save(image_path)

                old_name = pre_name.strip()
                existing = next((ch for ch in assets["characters"] if ch["name"] == old_name), None)

                if existing:
                    existing["name"] = cname.strip()
                    existing["description"] = cdesc.strip()
                    if image_path:
                        existing["image_path"] = image_path
                else:
                    assets["characters"].append({
                        "name": cname.strip(),
                        "description": cdesc.strip(),
                        "image_path": image_path
                    })

                save_assets(assets)
                st.session_state["edit_mode"] = None
                st.session_state["edit_target"] = None
                st.rerun()

        st.markdown("#### Or Generate Character Image with AI (Demo)")
        char_ai_prompt = st.text_input(
            "AI Visual Prompt (optional)",
            value="Black-and-white storyboard sketch of a cinematic character."
        )

        if st.button("✨ Generate Character Image using AI"):
            if not cname.strip():
                st.error("Enter a character name first.")
            else:
                slug = slugify_name(cname)
                out_path = os.path.join(CHAR_DIR, f"{slug}.png")
                full_prompt = f"Storyboard-style sketch of {cname}. {char_ai_prompt}"

                img = generate_ai_image(full_prompt, out_path, label=cname)

                found = next((ch for ch in assets["characters"]
                              if ch["name"].lower() == cname.strip().lower()), None)

                if found:
                    found["description"] = cdesc.strip()
                    found["image_path"] = out_path
                else:
                    assets["characters"].append({
                        "name": cname.strip(),
                        "description": cdesc.strip(),
                        "image_path": out_path
                    })

                save_assets(assets)
                st.image(img, caption=f"AI character image: {cname}", use_container_width=True)
                st.success("AI character image generated and saved.")

    # Locations tab
    with tabs[1]:
        st.subheader("Locations")

        if st.session_state["edit_mode"] == "location":
            pre_lname = st.session_state["edit_target"]["name"]
            pre_ldesc = st.session_state["edit_target"].get("description", "")
        else:
            pre_lname = ""
            pre_ldesc = ""

        lname = st.text_input("Location Name", value=pre_lname)
        ldesc = st.text_area("Location Description", value=pre_ldesc, height=80)
        loc_upload = st.file_uploader("Upload Location Image (PNG/JPG)", type=["png","jpg","jpeg"])

        if st.button("💾 Save Location (with optional upload)"):
            if not lname.strip():
                st.error("Location name is required.")
            else:
                slug = slugify_name(lname)
                image_path = None

                if loc_upload:
                    img = Image.open(loc_upload).convert("RGB")
                    image_path = os.path.join(LOC_DIR, f"{slug}.png")
                    img.save(image_path)

                old_lname = pre_lname.strip()
                existing = next((loc for loc in assets["locations"] if loc["name"] == old_lname), None)

                if existing:
                    existing["name"] = lname.strip()
                    existing["description"] = ldesc.strip()
                    if image_path:
                        existing["image_path"] = image_path
                else:
                    assets["locations"].append({
                        "name": lname.strip(),
                        "description": ldesc.strip(),
                        "image_path": image_path
                    })

                save_assets(assets)
                st.session_state["edit_mode"] = None
                st.session_state["edit_target"] = None
                st.rerun()

        st.markdown("#### Or Generate Location Image with AI (Demo)")

        loc_ai_prompt = st.text_input(
            "AI Visual Prompt (optional)",
            value="Black-and-white storyboard sketch of a cinematic environment."
        )

        if st.button("✨ Generate Location Image using AI"):
            if not lname.strip():
                st.error("Enter a location name first.")
            else:
                slug = slugify_name(lname)
                out_path = os.path.join(LOC_DIR, f"{slug}.png")
                full_prompt = f"Storyboard-style cinematic environment: {lname}. {loc_ai_prompt}"

                img = generate_ai_image(full_prompt, out_path, label=lname)

                found = next((loc for loc in assets["locations"]
                              if loc["name"].lower() == lname.strip().lower()), None)

                if found:
                    found["description"] = ldesc.strip()
                    found["image_path"] = out_path
                else:
                    assets["locations"].append({
                        "name": lname.strip(),
                        "description": ldesc.strip(),
                        "image_path": out_path
                    })

                save_assets(assets)
                st.image(img, caption=f"AI location image: {lname}", use_container_width=True)
                st.success("AI location image generated and saved.")

# -------------------------
# CONTINUE BUTTON
# -------------------------
completed = len(assets["characters"]) > 0 and len(assets["locations"]) > 0

st.markdown(" ")
_, next_col = st.columns([1, 1])

with next_col:
    if completed:
        if st.button("➡️ Continue to Script"):
            st.switch_page("pages/2_Script.py")
    else:
        st.button("➡️ Continue to Script", disabled=True)
