import streamlit as st
import os
import json
from PIL import Image, ImageDraw, ImageFont
from openai import OpenAI
import base64

DATA_DIR = "data"
FRAMES_JSON = os.path.join(DATA_DIR, "storyboard_frames.json")
BEATS_JSON = os.path.join(DATA_DIR, "beats.json")

os.makedirs(DATA_DIR, exist_ok=True)
if not os.path.exists(FRAMES_JSON):
    json.dump([], open(FRAMES_JSON, "w"))
if not os.path.exists(BEATS_JSON):
    json.dump([], open(BEATS_JSON, "w"))

def load_json(path, default):
    try:
        return json.load(open(path, "r"))
    except:
        return default

def save_json(path, data):
    json.dump(data, open(path, "w"), indent=4)

frames = load_json(FRAMES_JSON, [])
beats = load_json(BEATS_JSON, [])

# Wizard lock
if not st.session_state.get("unlock_storyboard", False):
    st.error("⚠️ Complete the Beats step first.")
    st.stop()

# Placeholder generator (same style as Assets)
def create_placeholder(label, out_path):
    img = Image.new("RGB", (800, 800), "#1a1a1a")
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()

    text = f"AI ERROR\n{label}"
    w, h = draw.multiline_textbbox((0, 0), text, font=font)[2:]
    draw.multiline_text(
        ((800 - w) / 2, (800 - h) / 2),
        text,
        fill=(200, 200, 200),
        font=font,
        align="center"
    )
    img.save(out_path)
    return out_path

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

left, right = st.columns([1,1])

with left:
    st.title("🎬 Generate Storyboard Frames")
    st.markdown("""
    Here we will generate **AI storyboard frames** for each beat 🙂.

    The AI will create cinematic, black–and–white storyboard sketches.
    """)


with right:
    st.subheader("Click to Generate Frames")

    if st.button("✨ Generate Storyboard"):
        for beat in beats:
            prompt = f"Storyboard frame for: {beat['text']} in cinematic style."
            img_path = os.path.join(DATA_DIR, f"frame_{beat['id']}.png")

            try:
                response = client.images.generate(
                    model="gpt-4o-mini-image",
                    prompt=prompt,
                    size="1024x1024"
                )

                b64 = response.data[0].b64_json
                img_bytes = base64.b64decode(b64)
                open(img_path, "wb").write(img_bytes)

            except Exception:
                img_path = create_placeholder(f"Beat {beat['id']}", img_path)

            frames.append({
                "beat_id": beat["id"],
                "image_path": img_path
            })
            save_json(FRAMES_JSON, frames)

        st.success("All frames generated! (AI or placeholder mode)")

# Display frames
st.markdown("## 🎨 Storyboard Frames")

for idx, f in enumerate(frames):
    beat_id = f["beat_id"]
    img_path = f["image_path"]

    # DISPLAY FRAME IMAGE
    if os.path.exists(img_path):
        st.image(img_path, use_column_width=True)

    # BUTTONS UNDER EACH FRAME
    col1, col2 = st.columns([1,1])

    # --- EDIT FRAME BUTTON ---
    with col1:
        if st.button(f"✏️ Edit Frame {beat_id}", key=f"edit_{idx}"):

            # re-generate image for this beat only
            beat = next((b for b in beats if b["id"] == beat_id), None)
            if beat:
                prompt = f"Storyboard frame for: {beat['text']} in cinematic style."
                try:
                    response = client.images.generate(
                        model="gpt-4o-mini-image",
                        prompt=prompt,
                        size="1024x1024"
                    )
                    b64 = response.data[0].b64_json
                    img_bytes = base64.b64decode(b64)
                    open(img_path, "wb").write(img_bytes)
                except Exception:
                    create_placeholder(f"Beat {beat_id}", img_path)

                st.success(f"Frame {beat_id} updated!")
                st.rerun()

    # --- DELETE FRAME BUTTON ---
    with col2:
        if st.button(f"🗑️ Delete Frame {beat_id}", key=f"delete_{idx}"):

            # delete image file
            if os.path.exists(img_path):
                os.remove(img_path)

            # remove from json list
            frames = [x for x in frames if x["image_path"] != img_path]
            save_json(FRAMES_JSON, frames)

            st.warning(f"Frame {beat_id} deleted.")
            st.rerun()

    st.markdown("---")

# Unlock export
if len(frames) > 0:
    st.session_state["unlock_export"] = True
    st.markdown("## ➡️ Continue")
    if st.button("Proceed to Export"):
        st.switch_page("pages/6_Export.py")