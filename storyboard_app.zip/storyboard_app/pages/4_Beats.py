import streamlit as st
import os
import json

DATA_DIR = "data"
BEATS_JSON = os.path.join(DATA_DIR, "beats.json")
SCENES_JSON = os.path.join(DATA_DIR, "scenes.json")

# Ensure data directory
os.makedirs(DATA_DIR, exist_ok=True)
if not os.path.exists(BEATS_JSON):
    json.dump([], open(BEATS_JSON, "w"))
if not os.path.exists(SCENES_JSON):
    json.dump([], open(SCENES_JSON, "w"))

def load_json(path, default):
    try:
        return json.load(open(path, "r"))
    except:
        return default

def save_json(path, data):
    json.dump(data, open(path, "w"), indent=4)

scenes = load_json(SCENES_JSON, [])
beats = load_json(BEATS_JSON, [])

# Wizard lock
if not st.session_state.get("unlock_beats", False):
    st.error("⚠️ You must complete the Scenes step first.")
    st.stop()

# Layout
left, right = st.columns([1,1])

with left:
    st.title("🎼 Add Scene Beats")
    st.markdown("""
    Beats are **moments of action, emotion, or story movement**.

    Examples:
    - Character discovers a clue
    - Emotional shift
    - Surprise reveal
    - Conflict escalates

    Add beats to build the emotional rhythm of your scene.
    """)

with right:
    scene_options = [f"Scene {s['id']}: {s['summary'][:30]}..." for s in scenes]
    scene_choice = st.selectbox("Choose Scene 🏞️", ["Select"] + scene_options)

    if scene_choice != "Select":
        scene_id = int(scene_choice.split()[1].replace(":", ""))

        st.subheader("➕ Add Beat")
        beat_text = st.text_area("Beat Description")

        if st.button("Add Beat"):
            new_beat = {
                "id": len(beats) + 1,
                "scene_id": scene_id,
                "text": beat_text
            }
            beats.append(new_beat)
            save_json(BEATS_JSON, beats)
            st.success("Beat added!")

# ----------------------------
# Display Beats with EDIT/DELETE
# ----------------------------
st.markdown("### 🎶 Existing Beats")

if "edit_beat_id" not in st.session_state:
    st.session_state["edit_beat_id"] = None

for b in beats:
    st.markdown(f"**Beat {b['id']} (Scene {b['scene_id']}):** {b['text']}")

    col1, col2 = st.columns([0.15, 0.15])
    with col1:
        if st.button(f"✏️ Edit Beat {b['id']}"):
            st.session_state["edit_beat_id"] = b["id"]

    with col2:
        if st.button(f"🗑️ Delete Beat {b['id']}"):
            beats = [x for x in beats if x["id"] != b["id"]]
            # Reassign IDs to stay ordered
            for i, bt in enumerate(beats, start=1):
                bt["id"] = i
            save_json(BEATS_JSON, beats)
            st.success("Beat deleted!")
            st.session_state["edit_beat_id"] = None
            st.rerun()

    # EDIT MODE
    if st.session_state["edit_beat_id"] == b["id"]:
        edited_text = st.text_area("Edit Beat Text", b["text"], key=f"edit_text_{b['id']}")

        if st.button("Save Changes", key=f"save_edit_{b['id']}"):
            for beat in beats:
                if beat["id"] == b["id"]:
                    beat["text"] = edited_text
            save_json(BEATS_JSON, beats)
            st.success("Beat updated!")
            st.session_state["edit_beat_id"] = None
            st.rerun()

    st.markdown("---")

# Unlock storyboard
if len(beats) > 0:
    st.session_state["unlock_storyboard"] = True
    st.markdown("## ➡️ Continue")
    if st.button("Proceed to Storyboard"):
        st.switch_page("pages/5_Storyboard.py")
