import streamlit as st
import os
import json

DATA_DIR = "data"
SCENES_JSON = os.path.join(DATA_DIR, "scenes.json")
ASSETS_JSON = os.path.join(DATA_DIR, "assets.json")

# Ensure folders/files exist
os.makedirs(DATA_DIR, exist_ok=True)
if not os.path.exists(SCENES_JSON):
    json.dump([], open(SCENES_JSON, "w"))
if not os.path.exists(ASSETS_JSON):
    json.dump({"characters": [], "locations": []}, open(ASSETS_JSON, "w"))

def load_json(path, default):
    try:
        return json.load(open(path, "r"))
    except:
        return default

def save_json(path, data):
    json.dump(data, open(path, "w"), indent=4)

assets = load_json(ASSETS_JSON, {"characters": [], "locations": []})
scenes = load_json(SCENES_JSON, [])

# ----------------------
# EDIT STATE
# ----------------------
if "edit_scene" not in st.session_state:
    st.session_state["edit_scene"] = None   # scene dict being edited

# --- Wizard lock ---
if not st.session_state.get("unlock_scenes", False):
    st.error("⚠️ You must complete the Script step first.")
    st.stop()

# --- Layout ---
left, right = st.columns([1,1])

# LEFT: Instructions
with left:
    st.title("🎬 Build Your Scenes")
    st.markdown("""
    Scenes are the backbone of your story.

    A scene should answer:
    - **Where** does it take place?
    - **When** does it occur?
    - **Who** is present?
    - **What** happens?
    """)

# RIGHT: Add/Edit Panel
with right:

    if st.session_state["edit_scene"]:
        st.subheader(f"✏️ Edit Scene {st.session_state['edit_scene']['id']}")
        editing = st.session_state["edit_scene"]
    else:
        st.subheader("➕ Add New Scene")
        editing = None

    # Dynamic options
    location_names = [loc["name"] for loc in assets["locations"]]
    char_names = [ch["name"] for ch in assets["characters"]]

    # PREFILL values if editing
    pre_location = editing["location"] if editing else "Select"
    pre_time = editing["time"] if editing else ""
    pre_summary = editing["summary"] if editing else ""
    pre_characters = editing["characters"] if editing else []

    location = st.selectbox("Location 📍", ["Select"] + location_names, index=(["Select"] + location_names).index(pre_location))
    time_of_day = st.text_input("Time of Day ☀️ (e.g., Night, Morning)", value=pre_time)
    summary = st.text_area("Scene Summary 🌄", value=pre_summary)
    characters = st.multiselect("Characters in Scene 🎞️", char_names, default=pre_characters)

    # --- Save Scene ---
    if st.button("💾 Save Scene"):
        if location == "Select":
            st.error("Location is required.")
        else:
            if editing:
                # UPDATE EXISTING SCENE
                editing["location"] = location
                editing["time"] = time_of_day
                editing["summary"] = summary
                editing["characters"] = characters
            else:
                # ADD NEW SCENE
                new_scene = {
                    "id": len(scenes) + 1,
                    "location": location,
                    "time": time_of_day,
                    "summary": summary,
                    "characters": characters
                }
                scenes.append(new_scene)

            save_json(SCENES_JSON, scenes)

            # Reset edit mode
            st.session_state["edit_scene"] = None
            st.success("Scene saved!")
            st.rerun()

# ----------------------
# EXISTING SCENES
# ----------------------
st.markdown("### 🎥 Existing Scenes")

for sc in scenes:
    st.markdown(f"**Scene {sc['id']} — {sc['location']} ({sc['time']})**")
    st.write(sc.get("summary", "_No summary available_"))
    st.caption("Characters: " + ", ".join(sc["characters"]))

    edit_col, del_col = st.columns([1,1])

    # --- Edit Button ---
    with edit_col:
        if st.button(f"✏️ Edit Scene {sc['id']}", key=f"edit_{sc['id']}"):
            st.session_state["edit_scene"] = sc
            st.rerun()

    # --- Delete Button ---
    with del_col:
        if st.button(f"🗑️ Delete Scene {sc['id']}", key=f"delete_{sc['id']}"):
            scenes = [s for s in scenes if s["id"] != sc["id"]]

            # Reassign IDs cleanly
            for i, s in enumerate(scenes, start=1):
                s["id"] = i

            save_json(SCENES_JSON, scenes)
            st.success("Scene deleted.")
            st.rerun()

    st.markdown("---")

# Unlock next step
if len(scenes) > 0:
    st.session_state["unlock_beats"] = True
    st.markdown("## ➡️ Continue")
    if st.button("Proceed to Beats"):
        st.switch_page("pages/4_Beats.py")
