import streamlit as st
import os
import json

# ----------------------------
# Load / Save Script Utilities
# ----------------------------
SCRIPT_PATH = "data/script.txt"

def load_script():
    if os.path.exists(SCRIPT_PATH):
        with open(SCRIPT_PATH, "r") as f:
            return f.read()
    return ""

def save_script(text):
    with open(SCRIPT_PATH, "w") as f:
        f.write(text)

# ----------------------------
# Fallback Dummy Script
# ----------------------------
FALLBACK_SCRIPT = """
Scene 1 – DEFAULT SCENE
Location: Jungle
Characters: Lion, Rabbit

ACTION:
The Lion and Rabbit interact dramatically in a neutral scene.
Other animals observe from a distance.

Scene 2 – DEFAULT RESOLUTION
Location: Jungle
Characters: Lion, Rabbit

ACTION:
The conflict resolves as the animals continue their journey.
""".strip()

# ----------------------------
# AI Script Generation
# ----------------------------
def generate_ai_script(prompt):
    """
    Attempts to generate an AI script.
    If AI fails (billing, API error, etc.), fallback dummy script is returned.
    """

    try:
        from openai import OpenAI
        client = OpenAI()

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You write 1–3 scene scripts for short animated stories."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=400
        )

        script_text = response.choices[0].message.content.strip()
        return script_text

    except Exception as e:
        # Display the error in Streamlit but continue
        st.error(f"AI Error: {e}")
        st.info("⚠️ Using fallback script instead (AI unavailable).")
        return FALLBACK_SCRIPT

# ----------------------------
# UI Layout
# ----------------------------
st.title(" 🖊️🗒️ STEP 2 · SCRIPT")
st.subheader("Write / Paste Your Script")
st.write(
    "Keep it short (1–3 scenes). This script will be used to create scenes, beats, "
    "and AI storyboard frames."
)

current_script = load_script()
script_input = st.text_area(
    "Your Script",
    value=current_script,
    height=350,
    placeholder="Write or generate your script here…"
)

# ----------------------------
# Save Script Button
# ----------------------------
if st.button("💾 Save Script", type="primary"):
    save_script(script_input)
    st.success("Script saved successfully!")
    st.session_state["unlock_scenes"] = True

# ----------------------------
# AI Script Button (with fallback)
# ----------------------------
st.markdown("### Or Generate Script with AI ✨ ")

ai_prompt = st.text_input(
    "Enter story idea (optional)",
    placeholder="Example: A greedy lion learns a lesson from a clever rabbit."
)

if st.button("✨ Generate Script with AI (Fallback Enabled)"):
    if not ai_prompt.strip():
        st.warning("Please enter a story idea for AI to generate a script.")
    else:
        generated = generate_ai_script(ai_prompt)
        save_script(generated)
        st.session_state["unlock_scenes"] = True
        st.success("Script generated and saved!")
        st.text_area("Generated Script", value=generated, height=350)

# ----------------------------
# Continue Button
# ----------------------------
if st.button("➡️ Continue to Scenes"):
    latest_script = script_input.strip() or load_script().strip()

    if not latest_script:
        st.error("Please enter or generate a script before continuing.")
    else:
        save_script(latest_script)
        st.switch_page("pages/3_Scenes.py")

# ----------------------------
# Back Button
# ----------------------------
st.button("🏠 Back to Home", on_click=lambda: st.switch_page("_Home.py"))
