import streamlit as st
import os
import json
from PIL import Image
import imageio

DATA_DIR = "data"
FRAMES_JSON = os.path.join(DATA_DIR, "storyboard_frames.json")

if not os.path.exists(FRAMES_JSON):
    json.dump([], open(FRAMES_JSON, "w"))

frames = json.load(open(FRAMES_JSON, "r"))
paths = [x["image_path"] for x in frames if os.path.exists(x["image_path"])]

if not st.session_state.get("unlock_export", False):
    st.error("⚠️ Generate storyboard frames first.")
    st.stop()

left, right = st.columns([1,1])

with left:
    st.title("📤 Export Your Storyboard")
    st.markdown("""
    Download your completed storyboard as:
    - **PNG Strip**
    - **GIF Animatic**
    - **PDF**
    """)

with right:
    if len(paths) == 0:
        st.warning("No frames found.")
        st.stop()

    images = [Image.open(p) for p in paths]
    widths, heights = zip(*(i.size for i in images))

    # PNG Strip
    strip = Image.new("RGB", (sum(widths), max(heights)))
    x = 0
    for im in images:
        strip.paste(im, (x, 0))
        x += im.width

    strip.save("storyboard_strip.png")
    st.download_button("⬇️ Download PNG Strip", open("storyboard_strip.png", "rb"), "storyboard_strip.png")

    # GIF
    imageio.mimsave("storyboard.gif", images, duration=0.8)
    st.download_button("⬇️ Download GIF", open("storyboard.gif", "rb"), "storyboard.gif")

    # PDF
    images[0].save("storyboard.pdf", save_all=True, append_images=[img.convert("RGB") for img in images[1:]])
    st.download_button("⬇️ Download PDF", open("storyboard.pdf", "rb"), "storyboard.pdf")
