import streamlit as st
import os

st.set_page_config(page_title="AI Storyboard Studio", page_icon="🎬", layout="wide")

# --------- GLOBAL CSS: hide sidebar + split layout ----------
st.markdown("""
<style>
[data-testid="stSidebar"], [data-testid="collapsedControl"] {
    display: none !important;
}
[data-testid="stAppViewContainer"] {
    background: radial-gradient(circle at top, #181A20 0%, #050509 55%, #000000 100%) !important;
}
body, html { background: #000000 !important; }

.main-title {
    font-size: 42px;
    font-weight: 900;
    color: #ffffff;
    margin-bottom: 0.4rem;
}
.sub-title {
    font-size: 18px;
    color: #d0d0d0;
    margin-bottom: 1.5rem;
}
.step-badge {
    display:inline-block;
    padding:4px 10px;
    border-radius:999px;
    background:#222330;
    color:#ff9f43;
    font-size:12px;
    margin-bottom:0.5rem;
}
.wizard-panel {
    background: rgba(12, 12, 18, 0.94);
    border-radius: 18px;
    border: 1px solid #2c2c3a;
    padding: 2rem;
}
div.stButton > button:first-child {
    background-color: #e50914 !important;
    color: white !important;
    font-weight: 700 !important;
    padding: 0.7rem 1.8rem !important;
    border-radius: 999px !important;
    border: none !important;
}
div.stButton > button:first-child:hover {
    background-color: #b20710 !important;
    transform: translateY(-1px);
}
</style>
""", unsafe_allow_html=True)

# --------- Progress init ----------
if "max_step" not in st.session_state:
    st.session_state["max_step"] = 1   # 1 = Home

# --------- Layout ----------
left, right = st.columns([1, 1])

with left:
    st.markdown("<div class='step-badge'>STEP 1 · OVERVIEW</div>", unsafe_allow_html=True)
    st.markdown("<div class='main-title'>🎬 Softscene AI Studio</div>", unsafe_allow_html=True)
    st.markdown(
        "<div class='sub-title'>Bring your ideas to life one step at a time. Go from a simple story concept → characters → locations → scenes → beats → storyboard frames → final export.</div>",
        unsafe_allow_html=True,
    )

    st.markdown("""
- You’ll move through **6 steps** in order.
- Each step unlocks the next (no skipping).
- At key steps the app uses **AI** to generate images from your story.
""")

    st.markdown("### Workflow")
    st.markdown("""
1. **Assets** – Build your characters and world with optional AI images.  
2. **Script** – Paste or write your script with AI ready to help if needed.  
3. **Scenes** – Turn scenes into structured moments.  
4. **Beats** – Capture emotional & action beats.  
5. **Storyboard** – Generate storyboard frames.  
6. **Export** – Export everything however you want. (PNG strip, GIF animatic, or PDF).
""")

with right:
    st.markdown("<div class='wizard-panel'>", unsafe_allow_html=True)
    st.markdown("### Ready to Begin?")
    st.write("You’ll start by defining your **characters** and **locations**.")
    st.write("Once Assets are done, the wizard will guide you to Script, Scenes, Beats, Storyboard, and Export.")

    if st.button("🚀 Let's create your movie!"):
        st.session_state["max_step"] = max(st.session_state["max_step"], 2)
        st.switch_page("pages/1_Assets.py")

    st.markdown("---")
    st.caption("Tip: keep your story short (1–3 scenes) so the demo feels smooth.")
    st.markdown("</div>", unsafe_allow_html=True)
